
def compare_validate(list1, list2): return [x for x in list1 + list2 if x not in list1 or x not in list2]