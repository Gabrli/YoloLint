import os
def add_file_to_list(path):
    return [img for img in os.listdir(path)]
  

        