BASIC_FOLDERS = ['images', 'labels']
CHILD_FOLDERS = ['train', 'val']